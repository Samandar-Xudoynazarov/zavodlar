globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Vro7V-B-u8Gprt4EI8g8x/_buildManifest.js",
    "static/Vro7V-B-u8Gprt4EI8g8x/_ssgManifest.js",
    "static/Vro7V-B-u8Gprt4EI8g8x/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1inwntv0b4r-7.js",
    "static/chunks/3c_bae98q44oq.js",
    "static/chunks/1io3cm__8tyxw.js",
    "static/chunks/turbopack-1lz11k206q_h7.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
